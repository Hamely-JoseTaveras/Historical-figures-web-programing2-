<?php
//accessing the database: distance_ny_capital_db
//need to setup 4 parameters
$server = "localhost";
$user = "root";
$password = "";
$database = "historical.figures.db";

//create a connection to the database
$condb = mysqli_connect($server,$user,$password,$database) or die("No connection");

//database table
$dbtable = "historical_figures_table";

//create a SQL select command to retrieve all the records
$SQLselect = "select * from " . $dbtable;

//run the above SQL command, use PHP function mysqli_query()
//the result of the run is stored in a variable called result
$result = mysqli_query($condb,$SQLselect) or die("SQl did not run");

//number of records
$numrecs = mysqli_num_rows($result);

if ($numrecs > 0)
{
    //send start of select element to HTML
    //before we loop through the database records
    print "<select id='historicalFiguresList' size='10' onchange='showinfo()'>";
    print "<option value=''>Select name </option>";

    //loop through the records
    while ($recordArray = mysqli_fetch_array($result))
    {
        $name = $recordArray[0];
        $nationality = $recordArray[1];
        $profession = $recordArray[2];
        $picture = $recordArray[3];

        //option value
        $optionValue = $name.",".$nationality.",".$profession.",".$picture;

        //send select option to HTML
        print "<option value='" . $optionValue . "'>". $name."</option>";
    } //end of loop

    //send close select to HTML
    print "</select>";
}
else print "No data available";
?>
